package org.asdc.medhub.Utility.Enums;

/**
 * Status of appointments
 */
public enum AppointmentStatus {
    BOOKED,
    CANCELLED,
    COMPLETED
}
