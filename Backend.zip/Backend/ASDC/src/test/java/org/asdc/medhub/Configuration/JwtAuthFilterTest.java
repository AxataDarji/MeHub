package org.asdc.medhub.Configuration;

public class JwtAuthFilterTest {
}
