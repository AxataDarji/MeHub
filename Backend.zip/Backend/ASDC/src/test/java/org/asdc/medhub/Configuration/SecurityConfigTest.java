package org.asdc.medhub.Configuration;

public class SecurityConfigTest {
}
