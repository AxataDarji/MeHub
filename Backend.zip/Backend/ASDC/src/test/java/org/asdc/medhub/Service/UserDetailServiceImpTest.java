package org.asdc.medhub.Service;

public class UserDetailServiceImpTest {
}
